import enum

class StachVersion(enum.Enum):
    V1 = 1
    V2 = 2
